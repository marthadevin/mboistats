angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('selamatDatang', {
    url: '/page1',
    templateUrl: 'templates/selamatDatang.html',
    controller: 'selamatDatangCtrl'
  })

  .state('menu.tingkatKemiskinan', {
    url: '/page2',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tingkatKemiskinan.html',
        controller: 'tingkatKemiskinanCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.beranda', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/beranda.html',
        controller: 'berandaCtrl'
      }
    }
  })

  .state('menu.kependudukan', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/kependudukan.html',
        controller: 'kependudukanCtrl'
      }
    }
  })

  .state('menu.kemiskinan', {
    url: '/page6',
    views: {
      'side-menu21': {
        templateUrl: 'templates/kemiskinan.html',
        controller: 'kemiskinanCtrl'
      }
    }
  })

  .state('menu.indeksPembangunanManusia', {
    url: '/page7',
    views: {
      'side-menu21': {
        templateUrl: 'templates/indeksPembangunanManusia.html',
        controller: 'indeksPembangunanManusiaCtrl'
      }
    }
  })

  .state('menu.ketenagakerjaan', {
    url: '/page8',
    views: {
      'side-menu21': {
        templateUrl: 'templates/ketenagakerjaan.html',
        controller: 'ketenagakerjaanCtrl'
      }
    }
  })

  .state('menu.perekonomian', {
    url: '/page9',
    views: {
      'side-menu21': {
        templateUrl: 'templates/perekonomian.html',
        controller: 'perekonomianCtrl'
      }
    }
  })

  .state('menu.tentang', {
    url: '/page10',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tentang.html',
        controller: 'tentangCtrl'
      }
    }
  })

  .state('menu.giniRasio', {
    url: '/page11',
    views: {
      'side-menu21': {
        templateUrl: 'templates/giniRasio.html',
        controller: 'giniRasioCtrl'
      }
    }
  })

  .state('menu.iPM', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/iPM.html',
        controller: 'iPMCtrl'
      }
    }
  })

  .state('menu.usiaHarapanHidup', {
    url: '/page13',
    views: {
      'side-menu21': {
        templateUrl: 'templates/usiaHarapanHidup.html',
        controller: 'usiaHarapanHidupCtrl'
      }
    }
  })

  .state('menu.harapanLamaSekolah', {
    url: '/page14',
    views: {
      'side-menu21': {
        templateUrl: 'templates/harapanLamaSekolah.html',
        controller: 'harapanLamaSekolahCtrl'
      }
    }
  })

  .state('menu.rataRataLamaSekolah', {
    url: '/page15',
    views: {
      'side-menu21': {
        templateUrl: 'templates/rataRataLamaSekolah.html',
        controller: 'rataRataLamaSekolahCtrl'
      }
    }
  })

  .state('menu.dayaBeli', {
    url: '/page16',
    views: {
      'side-menu21': {
        templateUrl: 'templates/dayaBeli.html',
        controller: 'dayaBeliCtrl'
      }
    }
  })

  .state('menu.indeksKedalamanKemiskinan', {
    url: '/page17',
    views: {
      'side-menu21': {
        templateUrl: 'templates/indeksKedalamanKemiskinan.html',
        controller: 'indeksKedalamanKemiskinanCtrl'
      }
    }
  })

  .state('menu.indeksKeparahanKemiskinan', {
    url: '/page18',
    views: {
      'side-menu21': {
        templateUrl: 'templates/indeksKeparahanKemiskinan.html',
        controller: 'indeksKeparahanKemiskinanCtrl'
      }
    }
  })

  .state('menu.garisKemiskinan', {
    url: '/page19',
    views: {
      'side-menu21': {
        templateUrl: 'templates/garisKemiskinan.html',
        controller: 'garisKemiskinanCtrl'
      }
    }
  })

  .state('menu.menurutJenisKelamin', {
    url: '/page20',
    views: {
      'side-menu21': {
        templateUrl: 'templates/menurutJenisKelamin.html',
        controller: 'menurutJenisKelaminCtrl'
      }
    }
  })

  .state('menu.menurutKecamatan', {
    url: '/page21',
    views: {
      'side-menu21': {
        templateUrl: 'templates/menurutKecamatan.html',
        controller: 'menurutKecamatanCtrl'
      }
    }
  })

  .state('menu.angkatanKerja', {
    url: '/page22',
    views: {
      'side-menu21': {
        templateUrl: 'templates/angkatanKerja.html',
        controller: 'angkatanKerjaCtrl'
      }
    }
  })

  .state('menu.pengangguranTerbuka', {
    url: '/page23',
    views: {
      'side-menu21': {
        templateUrl: 'templates/pengangguranTerbuka.html',
        controller: 'pengangguranTerbukaCtrl'
      }
    }
  })

  .state('menu.partisipasiAngkatanKerja', {
    url: '/page24',
    views: {
      'side-menu21': {
        templateUrl: 'templates/partisipasiAngkatanKerja.html',
        controller: 'partisipasiAngkatanKerjaCtrl'
      }
    }
  })

  .state('menu.lajuPertumbuhanEkonomi', {
    url: '/page25',
    views: {
      'side-menu21': {
        templateUrl: 'templates/lajuPertumbuhanEkonomi.html',
        controller: 'lajuPertumbuhanEkonomiCtrl'
      }
    }
  })

  .state('menu.inflasi', {
    url: '/page26',
    views: {
      'side-menu21': {
        templateUrl: 'templates/inflasi.html',
        controller: 'inflasiCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1')


});